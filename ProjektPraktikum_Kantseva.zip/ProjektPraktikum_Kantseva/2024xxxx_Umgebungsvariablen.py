# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 11:09:34 2023

@author: Kerstin
"""


import numpy as np
#import cv2
import matplotlib.pyplot as plt
import os
from scipy.interpolate import CubicSpline
import matplotlib
from scipy.signal import savgol_filter

import datetime as datetime
from datetime import datetime as dt


params = {'mathtext.default': 'regular' }          
plt.rcParams.update(params)


# ein paar Einstellungen zur Schriftart:
font = {'family' : 'DejaVu Sans',
        'weight' : 'normal',
        'size'   : 12}
#updaten der matplotlib 
matplotlib.rc('font', **font)

ZFZF = lambda x,pos: str(round(x,7)).rstrip('0').rstrip('.')

#%% colors
indigo='#332288'
cyan='#33bbee'
teal='#22aa88'
green='#117733'
olive='#999933'
sand='#eedd77'
rose='#DD6677'
wine='#882255'
purple='#aa4499'
blue='#0077bb'
orange='#ee7733'
red='#cc3311'
magenta='#ee3377'
gray='#AAAAAA'

teal2='#009988'

#%%
def concatenate_files(file1_path, file2_path, output_file_path):
    # Read the contents of the first file
    with open(file1_path, 'r') as file1:
        content1 = file1.read()

    # Read the contents of the second file
    with open(file2_path, 'r') as file2:
        content2 = file2.read()

    # Concatenate the contents
    combined_content = content1 + content2

    # Write the combined content to the output file
    with open(output_file_path, 'w') as output_file:
        output_file.write(combined_content)
        
        
def replace_commas_with_space_in_place(file_path):
    # Read the content of the file
    with open(file_path, 'r') as file:
        content = file.read()

    # Replace commas with spaces
    modified_content = content.replace(',', ' ')

    # Write the modified content back to the file
    with open(file_path, 'w') as file:
        file.write(modified_content)
#%%


environmentfile = r"C:\Users\Asusn\JupyterNotebook\aelotron\2024_07_26_10_38_10_194617-2-anemometer-microseconds-spindown-ab-15.50.asc"

plotpath=r"C:\Users\Asusn\JupyterNotebook\aelotron\\"


print(environmentfile)


a1list=[]
a2list=[]
a1elapsedlist=[]
a2elapsedlist=[]

Twlist=[]
Talist=[]
Telapsedlist=[]

thresh=10000

with open(environmentfile,'r') as infile:
    lines=infile.readlines()
    data=lines[1].split()
    datestring=data[0]+" "+data[1]
    starttime=dt.strptime(datestring,"%Y-%m-%d %H:%M:%S.%f")
    datestring=data[0]
    startday=dt.strptime(datestring,"%Y-%m-%d")
    a1last=2.0
    a2last=2.0
    for line in lines[1:]:
        data=line.split()
        datestring=data[0]+" "+data[1]
        try:
            elapsedtime=dt.strptime(datestring,"%Y-%m-%d %H:%M:%S.%f")-startday
        except ValueError:
            elapsedtime=dt.strptime(datestring,"%Y-%m-%d %H:%M:%S")-startday
            
        elapsedtime=elapsedtime.total_seconds()
        
        if(data[2]=="a1:"):  
            vel=1000000.0/float(data[4])/72
            if ( (vel<3*a1last and vel>0.25) or (vel>0 and vel<0.5)):
                #print(vel)
                a1elapsedlist.append(elapsedtime)
                a1list.append(vel)
                a1last=vel
        if(data[2]=="a2:"):
            vel=1000000.0/float(data[4])/72
            if ((vel<3*a2last and vel>0.25) or (vel>0 and vel<0.5)):
                a2elapsedlist.append(elapsedtime)
                a2list.append(vel)
                a2last=vel
        if(data[2]=="T:"):
            Telapsedlist.append(elapsedtime)           
            Twlist.append(float(data[3]))
            Talist.append(float(data[5]))
        
a1list.pop(0)
a2list.pop(0)
a1elapsedlist.pop(0)
a2elapsedlist.pop(0)

        
a1elapsed=np.array(a1elapsedlist)
a1elapsed=a1elapsed/3600
a2elapsed=np.array(a2elapsedlist)
a2elapsed=a2elapsed/3600
a1=np.array(a1list)
a2=np.array(a2list)

print(min(a1),min(a2))

Telapsed=np.array(Telapsedlist)/3600.0
Ta=np.array(Talist)
Tw=np.array(Twlist)

a1smooth=a1
a2smooth=a2
#%%

fig, ax = plt.subplots(figsize = (9,6))
#plt.ylim([-0.01,0.2])
#plt.xlim([14.5,17.5])

plt.xlabel('time of day [h]')
plt.ylabel('water velocity [maybe m/s]')


ax.plot(a1elapsed,a1smooth,label="water anemometer a1")
ax.plot(a2elapsed,a2smooth,label="water anemometer a2")

plt.grid(visible=True, which='major', color='grey', linestyle='-')
ax.legend(bbox_to_anchor=(0.005, 0.995), loc=2, borderaxespad=0.,fancybox=True, framealpha=1.0,fontsize=10,borderpad=0.2,labelspacing=0.35,handletextpad=0.1)


plt.show()
plotfilename=plotpath+"20240725-water-velocity.pdf"
print(plotfilename)
fig.savefig(plotfilename)

#%%

fig, ax = plt.subplots(figsize = (9,6))
#plt.ylim([-0.01,0.2])
#plt.xlim([14.5,17.5])

plt.xlabel('time of day [h]')
plt.ylabel('temperature [oC]')


ax.plot(Telapsed,Ta,label="Air Temperature")
ax.plot(Telapsed,Tw,label="Water Temperature")

plt.grid(visible=True, which='major', color='grey', linestyle='-')
ax.legend(bbox_to_anchor=(0.995, 0.995), loc=1, borderaxespad=0.,fancybox=True, framealpha=1.0,fontsize=10,borderpad=0.2,labelspacing=0.35,handletextpad=0.1)


plt.show()
plotfilename=plotpath+"20240725-temperatures.pdf"
print(plotfilename)
fig.savefig(plotfilename)

#%%




